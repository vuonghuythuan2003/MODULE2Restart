create
    definer = root@localhost procedure Proc_DeleteProduct(IN p_id int)
BEGIN
    DELETE FROM Products WHERE product_id = p_id;
END;


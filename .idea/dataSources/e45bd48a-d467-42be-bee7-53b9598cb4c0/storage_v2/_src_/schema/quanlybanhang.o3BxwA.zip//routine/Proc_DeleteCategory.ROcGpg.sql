create
    definer = root@localhost procedure Proc_DeleteCategory(IN cat_id int)
BEGIN
    -- Kiểm tra nếu danh mục có sản phẩm thì không xóa
    IF EXISTS (SELECT 1 FROM Products WHERE category_id = cat_id) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Không thể xóa danh mục có sản phẩm!';
    ELSE
        DELETE FROM Categories WHERE category_id = cat_id;
    END IF;
END;


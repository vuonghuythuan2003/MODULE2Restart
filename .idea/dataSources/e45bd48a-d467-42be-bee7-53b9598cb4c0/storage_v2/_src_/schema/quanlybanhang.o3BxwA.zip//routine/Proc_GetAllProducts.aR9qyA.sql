create
    definer = root@localhost procedure Proc_GetAllProducts()
BEGIN
    SELECT * FROM Products;
END;


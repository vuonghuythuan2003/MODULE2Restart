create
    definer = root@localhost procedure Proc_FindProductsByPriceRange(IN min_price double, IN max_price double)
BEGIN
    SELECT * FROM Products
    WHERE selling_price BETWEEN min_price AND max_price;
END;


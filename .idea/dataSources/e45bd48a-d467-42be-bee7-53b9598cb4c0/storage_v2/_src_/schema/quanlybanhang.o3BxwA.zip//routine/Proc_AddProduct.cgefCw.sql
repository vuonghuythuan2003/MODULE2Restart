create
    definer = root@localhost procedure Proc_AddProduct(IN p_name varchar(20), IN p_stock int, IN p_cost_price double,
                                                       IN p_selling_price double, IN p_category_id int)
BEGIN
    INSERT INTO Products (product_name, stock, cost_price, selling_price, category_id)
    VALUES (p_name, p_stock, p_cost_price, p_selling_price, p_category_id);
END;


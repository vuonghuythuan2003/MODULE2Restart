create
    definer = root@localhost procedure Proc_UpdateProduct(IN p_id int, IN p_name varchar(20), IN p_stock int,
                                                          IN p_cost_price double, IN p_selling_price double,
                                                          IN p_category_id int)
BEGIN
    UPDATE Products
    SET product_name = p_name,
        stock = p_stock,
        cost_price = p_cost_price,
        selling_price = p_selling_price,
        category_id = p_category_id
    WHERE product_id = p_id;
END;


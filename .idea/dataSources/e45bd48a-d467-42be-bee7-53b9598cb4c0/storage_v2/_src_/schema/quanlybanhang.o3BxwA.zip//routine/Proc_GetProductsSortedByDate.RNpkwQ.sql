create
    definer = root@localhost procedure Proc_GetProductsSortedByDate()
BEGIN
    SELECT * FROM Products ORDER BY created_at DESC;
END;


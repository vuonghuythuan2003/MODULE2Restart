create
    definer = root@localhost procedure Proc_AddCategory(IN cat_name varchar(50))
BEGIN
    INSERT INTO Categories (category_name, category_status)
    VALUES (cat_name, 1);
END;


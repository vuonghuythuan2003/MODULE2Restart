create
    definer = root@localhost procedure Proc_GetTop3ProfitableProducts()
BEGIN
    SELECT *, (selling_price - cost_price) AS profit
    FROM Products
    ORDER BY profit DESC
    LIMIT 3;
END;


create
    definer = root@localhost procedure Proc_GetAllCategories()
BEGIN
    SELECT * FROM Categories;
END;


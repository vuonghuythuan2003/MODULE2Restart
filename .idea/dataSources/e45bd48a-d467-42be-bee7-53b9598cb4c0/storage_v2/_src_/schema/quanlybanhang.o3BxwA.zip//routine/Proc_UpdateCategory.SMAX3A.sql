create
    definer = root@localhost procedure Proc_UpdateCategory(IN cat_id int, IN cat_name varchar(50), IN cat_status bit)
BEGIN
    UPDATE Categories
    SET category_name = cat_name, category_status = cat_status
    WHERE category_id = cat_id;
END;

